var apiObj = null;

function StartMeeting(){
    const domain = 'meet.tutorsden.in';
    const options = {
        roomName: 'my',
        width: 700,
        height: 700,
        parentNode: document.querySelector('#jitsi-meet-conf-container')
    };
    apiObj = new JitsiMeetExternalAPI(domain, options);
}